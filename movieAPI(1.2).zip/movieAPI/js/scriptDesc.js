 
$(document).ready(()=>{
    fetchdesc();
    function fetchdesc(){
        $.ajax({
            url:"http://demo.tech2edge.co/samples/data-sg",
            type: "GET",
            dataType:"JSON",
            data:JSON.stringify({ }),
            success:function(data){
              let title =data.series.title;
              let description = data.series.desc;
              let img = data.series.img;
              let output =`
              <img style="width:100%; height:100%; margin-top:10%;"src="http://demo.tech2edge.co/samples/${img}">
              `;
              $('#test').html(output);
              document.getElementById('headingtitle').innerHTML = title;
              document.getElementById('description').innerHTML = description;
             let castinfo = data.characters;
             let output2='';
                $.each(castinfo,(index,info)=>{
                    output2 += `
                    <div class="row" style="margin-left:10%;">
<div class="column">
<img src="http://demo.tech2edge.co/samples/${info.img}" style="width:400px; " >
 <h5 style="color:white; text-align:center; font-family: "Times New Roman", Times, serif; font-weight: normal;">Name: ${info.name}</h5>
<h5 style="text-align:center; color:white;"> Age: ${info.age}</h5>
<h5 style="text-align:center; color:white;">Profession: ${info.profession}</h5>
</div>
</div>
                    `;
                })
              $('#test2').html(output2); 




              }
        });
    }

})